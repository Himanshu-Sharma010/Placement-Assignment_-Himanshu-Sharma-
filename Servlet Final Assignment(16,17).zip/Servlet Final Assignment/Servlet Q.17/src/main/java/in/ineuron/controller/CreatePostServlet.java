package in.ineuron.controller;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.dto.Post;


@WebServlet("/createPostServlet")
public class CreatePostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public  void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 // Get the title, description, and content from the request.
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String content = request.getParameter("content");

        // Create a new post with the given data.
        Post post = new Post();
        post.setTitle(title);
        post.setDescription(description);
        post.setContent(content);

        // Save the post to the database using JDBC.
        try {
            // Load the JDBC driver.
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Create a connection to the database.
            String url = "jdbc:mysql://localhost:3306/jdbcprep";
            String username = "root";
            String password = "04&LU$NsA!R";
            Connection connection = DriverManager.getConnection(url, username, password);


            // Insert the post into the database.
            String sql = "INSERT INTO posts (title, Description, content) VALUES (?, ?, ?)";
//            String sql = "INSERT INTO posts (title, Description) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
           
			
            preparedStatement.setString(1, post.getTitle());
            preparedStatement.setString(2, post.getDescription());
            preparedStatement.setString(3, post.getContent());
            preparedStatement.executeUpdate();

            // Close the connection.
            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Redirect the user to the home page.
        response.sendRedirect("index.jsp");

	}

}
