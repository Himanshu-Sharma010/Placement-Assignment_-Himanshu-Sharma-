package in.ineuron.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.dto.Post;

@WebServlet("/getPosts")
public class GetPostsServlet extends HttpServlet {

    @Override
    public  void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    	
    	try {
        // Create a list to store the posts.
        List<Post> posts = new ArrayList<>();
        
        // Load the JDBC driver.
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Create a connection to the database.
        String url = "jdbc:mysql://localhost:3306/jdbcprep";
        String username = "root";
        String password = "04&LU$NsA!R";
        Connection connection = DriverManager.getConnection(url, username, password);



        // Prepare a statement to get all posts.
        PreparedStatement statement = connection.prepareStatement("SELECT title, Description, content FROM posts");

        // Execute the statement and get the results.
        ResultSet results = statement.executeQuery();

        // Iterate through the results and add each post to the list.
        while (results.next()) {
            Post post = new Post();
            post.setTitle(results.getString("title"));
            post.setDescription(results.getString("Description"));
            post.setContent(results.getString("content"));
            posts.add(post);
        }

        // Close the connection to the database.
        connection.close();

        // Set the posts as the request attribute.
        request.setAttribute("posts", posts);
    	}catch (SQLException | ClassNotFoundException e) {

    		e.printStackTrace();
    	}

        // Forward the request to the JSP page.
        request.getRequestDispatcher("posts.jsp").forward(request, response);
    }
}

