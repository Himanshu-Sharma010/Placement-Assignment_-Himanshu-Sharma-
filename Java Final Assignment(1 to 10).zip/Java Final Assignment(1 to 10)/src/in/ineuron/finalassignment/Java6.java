package in.ineuron.finalassignment;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Java6 {

	public static void main(String[] args) {

		
        List<Integer> numbers = Arrays.asList(50,11,34,6,23,67,45,19,40);

        //sort the data in ascending order
        List<Integer> sortedNumbers = numbers.stream().sorted().collect(Collectors.toList());

        System.out.println(sortedNumbers);
        
        //filter out the data as even numbers
        List<Integer> evenNumbers = numbers.stream().filter(i -> i % 2 == 0).collect(Collectors.toList());

        System.out.println(evenNumbers);
	}

}
