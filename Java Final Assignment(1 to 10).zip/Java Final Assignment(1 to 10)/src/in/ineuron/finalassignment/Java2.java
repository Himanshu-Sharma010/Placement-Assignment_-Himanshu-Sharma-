package in.ineuron.finalassignment;


class Parent {

	public Parent() {
	System.out.println("Parent class construnctor called");
	
	}
}

class Child extends Parent{
	public Child() {
		
		super();//It calls Parent class constructor which have zero parameter.
		System.out.println("Child class Constructor called");
		
	}
	
	
}

public class Java2 {

	public static void main(String[] args) {

		Child child = new Child();
		
		/*
		 * Constructor---->
		 * It have no explicit return type.
		 * No return statement is allowed.
		 * When object is created constructor is called.
		 * this() use for call current class zero parameter constructor.
		 * In one constructor we can call only suoer() or this(). if anyone is called prviously then other will not be called by constructor it shows CE.
		 * It is a shortcut to avoid setter method.
		 * Constructor use for setting the values of instance variables.
		 * Whenever we call to a constructor if programmer has not specified constructor then jvm include zero parameter constructor automatically.
		 * 
		 */
		
	}

}
