package in.ineuron.finalassignment;



interface ISample{
	//100% abstract class
	
	//by default the methods are public and abstract in interface
	public static final int x = 19;//static used because java interfaces object cann't be created so to access the interface variables use static
	public static final int y = 89;//static used because java interfaces object cann't be created so to access the interface variables use static
   //static useful in variables conflict concept.
	void m1();
	void m2();
}


abstract class SampleImpl implements ISample{
	//overiding the methods 
	public void m1() {//make visibility public because by default visibility   becomes default type(~) that causes error.
	}//public visibilty make avability of that method to implementation class.
	public void m2() {
	}
	public int m3() {
		return 10;
	}
	
}

class SubSampleImpl extends SampleImpl{
	public void m1() {
		System.out.println("hello");
	}
	public void m2() {
		System.out.println("hi");
	}
}

public class Java5 {

	public static void main(String[] args) {
		
		ISample ob = new SubSampleImpl();//polymorphism
		System.out.println(ISample.x);
		ob.m1();
		ob.m2();

		/*Keypoints
		 * 
Abstract class:: If we are talking about implementation but not completely then we
should go for abstract class.
Interface:: Every method present inside the interface is always public and
abstract whether we are declaring or not.

Abstract :: Every method present inside abstract class need not be public and
abstract.
Interface:: We can't declare interface methods with the modifiers like
private,protected,final,static,synchronized,native,strictfp.

Abstract :: There are not restrictions on abstract class method modifiers.
Interface:: Every interface variable is always public static final whether we are
declaring or not.

Abstract:: Every abstract class variable need not be public static final.
Interface:: Every interface variable is always public static final we can't
declare with the following modifiers like private,protected,transient,volatile.


Interface:: For every interface variable compulsory we should perform
initialization at the time of declaration,otherwise we get compile time error.
Abstract:: Not required to perform initialization for abstract class variables
at the time of declaration.

Interface:: Inside interface we can't write static and instance block.
Abstract :: Inside abstract class we can write static and instance block.

Interface:: Inside interface we can't write constructor.
Abstract :: Inside abstract class we can write constructor.
		 */
		
	}

}
