package in.ineuron.finalassignment;

import java.util.Scanner;


class BankAccount{
	 private String accountNumber;
	    private String name;
	    private long balance;

	    public BankAccount(String accountNumber, String name, long balance) {
	        this.accountNumber = accountNumber;
	        this.name = name;
	        this.balance = balance;
	    }

	    public String getAccountNumber() {
	        return accountNumber;
	    }

	    public String getName() {
	        return name;
	    }

	    public long getBalance() {
	        return balance;
	    }

	    public void deposit(long amount) {
	        balance += amount;
	    }

	    public void withdraw(long amount) {
	        if (balance < amount) {
	            System.out.println("Insufficient balance");
	            return;
	        }

	        balance -= amount;
	    }

	    public void checkBalance() {
	        System.out.println("Your balance is " + balance);
	    }
	    
	    public void operation() {
	    	Scanner scanner  = new Scanner(System.in);
	    	 BankAccount bankAccount = new BankAccount(accountNumber, name, balance);

	    	 while (true) {
	    		 System.out.println();
	             	System.out.println("Welcome to our Bank!!!");
	                 System.out.println("Choose an option:: ");
	                 System.out.println("1. Deposit");
	                 System.out.println("2. Withdraw");
	                 System.out.println("3. Check balance");
	                 System.out.println("4. Exit");

	                 int choice = scanner.nextInt();

	                 switch (choice) {
	                     case 1:
	                         System.out.println("Enter the amount you want to deposit: ");
	                         long amount = scanner.nextLong();
	                         bankAccount.deposit(amount);
	                         break;

	                     case 2:
	                         System.out.println("Enter the amount you want to withdraw: ");
	                         amount = scanner.nextLong();
	                         bankAccount.withdraw(amount);
	                         break;

	                     case 3:
	                         bankAccount.checkBalance();
	                         break;

	                     case 4:
	                         System.out.println("Exiting...");
	                         System.exit(0);

	                     default:
	                         System.out.println("Invalid choice");
	                 }
	             }
	    }
	
}

public class Java4 {

	static String  accountNumber = null;
	static String name = null;
	 static long balance = 0;
	 
	
	public static void input() {
	
		  Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter your account number: ");
	         accountNumber = scanner.nextLine();

	        System.out.println("Enter your name: ");
	         name = scanner.nextLine();
	}
   

    public static void main(String[] args) {
    	
    	  Scanner scanner = new Scanner(System.in);
    
    	 
    	 String acNo =  "567890348954";
    	 String acName = "Himanshu";
    	 
    	Java4 java4 = new Java4();
    	java4.input();
      

       
        
         
       
        if (accountNumber.equals(acNo) && name.equals(acName)) {
        	 System.out.println("Enter your initial balance: ");
              balance = scanner.nextLong();
        	 BankAccount bankAccount = new BankAccount(accountNumber, name, balance);

        	 bankAccount.operation();
		}
        else {
			int count=3;
			while(count!=0) {
				System.out.println("Invalid Credential..");
				System.out.println("You have "+count+" chance for entering right credentials");
				System.out.println("Please enter valid credential again ");
				
				System.out.println("Enter your account number: ");
		         accountNumber = scanner.nextLine();

		        System.out.println("Enter your name: ");
		         name = scanner.nextLine();

		        
		        if (accountNumber.equals(acNo) && name.equals(acName)) {
		        	 System.out.println("Enter your initial balance: ");
		              balance = scanner.nextLong();
		        	 BankAccount bankAccount = new BankAccount(accountNumber, name, balance);

		        	 bankAccount.operation();
				}
		        count--;
				
			}
			if (count==0) {
				System.out.println("You have lost all your chances ");
				System.out.println("Now Your Account is locked");
				System.out.println("Please contact to Respective bank branch to unlock your account");
			}
		}

       
    }
}

