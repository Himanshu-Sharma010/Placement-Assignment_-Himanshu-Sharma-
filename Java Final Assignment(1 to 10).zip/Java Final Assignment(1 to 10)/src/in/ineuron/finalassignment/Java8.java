package in.ineuron.finalassignment;

public class Java8 {

    public static void main(String[] args) {
        Thread evenThread = new Thread(new Runnable() {
            @Override
            public void run() {
                printEvenNumbers();
            }
        });

        Thread oddThread = new Thread(new Runnable() {
            @Override
            public void run() {
                printOddNumbers();
            }
        });

        evenThread.start();
        oddThread.start();
    }

    private static void printEvenNumbers() {
        for (int i = 2; i <= 10; i += 2) {
            System.out.println(i);
        }
    }

    private static void printOddNumbers() {
        for (int i = 1; i <= 10; i += 2) {
            System.out.println(i);
        }
    }
}

