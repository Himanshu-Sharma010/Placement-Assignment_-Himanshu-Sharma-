package in.ineuron.finalassignment;

import java.util.Scanner;

class NegativeNumberException extends Exception{
	public NegativeNumberException(String msg) {
		super(msg);
	}
	
}

public class Java3 {


	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number :");
		int num = sc.nextInt();
		
		try {
			if (num<0) {
				NegativeNumberException ne = new NegativeNumberException("Number is negative");
				
				throw ne;
			}
			else {
				System.out.println(num + " is positive");
			}
		} catch (NegativeNumberException ne) {

			System.out.println(ne.getMessage());
		
		}finally {
			System.exit(0);
		}
		
		
	}
}
