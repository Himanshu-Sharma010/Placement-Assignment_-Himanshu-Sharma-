package in.ineuron.finalassignment;

import java.util.*;

public class Java10 {

    public static void main(String[] args) {

    	
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the size of the set");
        int size = scanner.nextInt();
        System.out.println("Enter a list of integers: ");

        List<Integer> list = new ArrayList<>();
        int arr[] = new int[size];
        
        for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
			list.add(arr[i]);
			
		}
        


        int secondLargest = 0;
        int secondSmallest = 0;

        Collections.sort(list);

        secondLargest = list.get(list.size() - 2);
        secondSmallest = list.get(1);

        System.out.println("The second largest element in the list is: " + secondLargest);
        System.out.println("The second smallest element in the list is: " + secondSmallest);
    }
}

