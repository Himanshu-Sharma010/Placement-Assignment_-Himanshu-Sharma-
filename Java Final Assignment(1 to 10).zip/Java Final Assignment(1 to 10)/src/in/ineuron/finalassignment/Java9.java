package in.ineuron.finalassignment;

import java.util.Random;

public class Java9 {

    private static final int QUEUE_SIZE = 10;

    private static int[] queue = new int[QUEUE_SIZE];
    private static int head = 0;
    private static int tail = 0;

    private static class Producer extends Thread {

        @Override
        public void run() {
            while (true) {
                int number = new Random().nextInt();
                System.out.println("Producer produced: " + number);
                synchronized (queue) {
                    while (tail == QUEUE_SIZE) {
                        try {
//                        	Thread.sleep(4000);
							queue.wait();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                    }
                    queue[tail++] = number;
                    queue.notifyAll();
                }
            }
        }
    }

    private static class Consumer extends Thread {

        @Override
        public void run() {
            while (true) {
                int number;
                synchronized (queue) {
                    while (head == tail) {
                        try {
//                        	Thread.sleep(4000);
							queue.wait();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                    }
                    number = queue[head++];
                    queue.notifyAll();
                }
                System.out.println("Consumer consumed: " + number);
            }
        }
    }

    public static void main(String[] args) {
        Producer producer = new Producer();
        Consumer consumer = new Consumer();

        producer.start();
        consumer.start();

        try {
            producer.join();
            consumer.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
