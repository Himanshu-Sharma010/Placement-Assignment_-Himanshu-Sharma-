package in.ineuron.finalAssignment;

import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.ineuron.model.InsurancePolicy;
import in.ineuron.util.HibernateUtil;

public class Hb19 {

	public static void main(String[] args) {

		Session session = null;
		Integer rowAffected  = null;
		Transaction transaction = null;
		boolean flag = false;

		try {

			session = HibernateUtil.getSession();

			if (session != null) {

				 transaction = session.beginTransaction();
				 
				 NativeQuery<InsurancePolicy> nQuery = session.createSQLQuery(
						"insert into insurancepolicy(pname,ptype,tenure) values(:pn,:pt,:te) ");

				nQuery.setParameter("pn", "PaytmFinance");
				nQuery.setParameter("pt", "Monthly");
				nQuery.setParameter("te", 300);
				
				rowAffected = nQuery.executeUpdate();
				
				if(rowAffected==1) {
					flag=true;
				}
				
			}

		} catch (HibernateException he) {

			he.printStackTrace();
			flag=false;
		} catch (Exception e) {
			e.printStackTrace();
			flag=false;
		} finally {
			
			if (flag) {
				transaction.commit();
				System.out.println("Record inserted to database :: "+rowAffected);
				 Query<InsurancePolicy> query =  session.createQuery("FROM in.ineuron.model.InsurancePolicy");
					
				 List<InsurancePolicy> list = query.getResultList();
				 
				 list.forEach(System.out::println);
			}
			else {
				transaction.rollback();
				System.out.println("Record not inserted to database:: "+rowAffected);
			}
			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}

	}

}
