package in.ineuron.finalAssignment;

import org.hibernate.query.Query;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import in.ineuron.model.InsurancePolicy;
import in.ineuron.util.HibernateUtil;

public class Hb18 {

	public static void main(String[] args) {
		
		Session session = null;
		
		try {
		
			
			 session = HibernateUtil.getSession();
			 
			 if(session!=null) {
				 
				 Query<InsurancePolicy> query =  session.createQuery("FROM in.ineuron.model.InsurancePolicy");
			
				 List<InsurancePolicy> list = query.getResultList();
				 
				 list.forEach(System.out::println);
			 
			 }

			
		} catch (HibernateException he) {

			he.printStackTrace();
		}catch (Exception e) {
                e.printStackTrace();
		}finally {
			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}

				
	}

}
