package in.ineuron.dao;

import java.util.List;

import in.ineuron.dto.Tabledtls;

public interface TableDao {
	
	public  List<Tabledtls> getAllTableData();

}
