package in.ineuron.dto;

import java.io.Serializable;

public class Tabledtls implements Serializable {
	

	private static final long serialVersionUID = 1L;
	
	private int pid;
	private String pname;
	private String ptype;
	private int tenure;
	
	
	public Tabledtls() {
		super();
	}


	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}


	public String getPname() {
		return pname;
	}


	public void setPname(String pname) {
		this.pname = pname;
	}


	public String getPtype() {
		return ptype;
	}


	public void setPtype(String ptype) {
		this.ptype = ptype;
	}


	public int getTenure() {
		return tenure;
	}


	public void setTenure(int tenure) {
		this.tenure = tenure;
	}


	@Override
	public String toString() {
		return "Tabledtls [pid=" + pid + ", pname=" + pname + ", ptype=" + ptype + ", tenure=" + tenure + "]";
	}
	
	
	
	
	
	
	

}
