package in.ineuron.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.dto.Tabledtls;
import in.ineuron.utilconnection.JdbcConnection;

public class TableDaoImpl implements TableDao {

	@Override
	public  List<Tabledtls> getAllTableData() {

		
		//Resources Used
		Connection connection = null;
		PreparedStatement pStatement = null;
		ResultSet rs = null;
		Tabledtls td = null;
		
		
		
		  
		  List<Tabledtls> list = new ArrayList<Tabledtls>();
		
		 try {
			 String sqlSelectQuery = "select * from insurancepolicy";
			connection = JdbcConnection.getJdbcConnection();
			
			if (connection!=null) {
				
				pStatement = connection.prepareStatement(sqlSelectQuery);
			}
			
			if(pStatement!=null) {
				rs = pStatement.executeQuery();
			}
			
			if(rs!=null) {
				while(rs.next()) {
					td = new Tabledtls();
					
					  td.setPid(rs.getInt("pid"));
                      td.setPname(rs.getString("pname"));  
					   td.setPtype(rs.getString("ptype"));
					   td.setTenure(rs.getInt("tenure"));
					      list.add(td);
					   
				}
			}
			
			
		} catch (SQLException | IOException e) {

			e.printStackTrace();
		}
		
		return list;
	}

}
