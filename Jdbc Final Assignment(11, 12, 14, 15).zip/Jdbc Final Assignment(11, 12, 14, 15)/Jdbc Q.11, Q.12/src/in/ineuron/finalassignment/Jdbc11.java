package in.ineuron.finalassignment;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.ineuron.utilconnection.JdbcConnection;



public class Jdbc11 {
	
	public static void main(String[] args) {
		
		
		//resources use
		Connection connection = null;
		PreparedStatement pStatement = null;
		ResultSet rs = null;
		
		//variables use
		int pid,tenure = 0;
		String pname = null;
		String ptype = null;
		
		
		try {
//			String sqlSelectQuery = "select * from insurancepolicy where pname=?";
			String sqlSelectQuery = "select * from insurancepolicy";
			connection = JdbcConnection.getJdbcConnection();
			
			if (connection!=null) {
				
				pStatement = connection.prepareStatement(sqlSelectQuery);
				
//				pStatement.setString(1,"Mutual" );
			}
			 
			
			
			 if (pStatement!=null) {
				
				 rs = pStatement.executeQuery();
			}
			   
			 
			   System.out.println("PID\tPNAME\tPTYPE\tTENURE");
			   while(rs.next()) {
				    pid = rs.getInt(1);
				    pname =  rs.getString("pname");
				   ptype  =  rs.getString("ptype");
				      tenure = rs.getInt(4);
				      
				      System.out.println(pid+"\t"+pname+"\t"+ptype+"\t"+tenure);
			   }
			  
			 
		} catch (SQLException se) {

			se.printStackTrace();
			
		}catch (IOException ie) {

			ie.printStackTrace();
		
		}finally {
			try {

				JdbcConnection.jdbcCleanUp(connection, pStatement, rs);
				
			} catch (SQLException se) {

				se.printStackTrace();
			}
		}
	}

}
